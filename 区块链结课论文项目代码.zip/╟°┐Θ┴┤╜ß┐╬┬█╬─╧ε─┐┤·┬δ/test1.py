from consensus.pow import PowConsensus
from consensus.pos import PosConsensus
from core.blockchain_manager import BlockChainManager
from core.transaction import Transaction

if __name__ == "__main__":
    # 切换到 PoW
    pow_consensus = PowConsensus(target_block_time_sec=5, initial_difficulty=2, miner_address="MinerA")
    manager = BlockChainManager(consensus_strategy=pow_consensus, mining_reward=10.0)

    # 加入几笔交易
    manager.add_transaction_to_pool(Transaction("Alice", "Bob", 5.0))
    manager.add_transaction_to_pool(Transaction("Bob", "Carol", 2.0))

    block = manager.create_new_block()
    if block and manager.add_block_to_chain(block):
        print("PoW 出块成功:", block.hash)

    # 切换到 PoS
    pos_consensus = PosConsensus({"ValidatorA": 100.0, "ValidatorB": 50.0})
    manager.consensus = pos_consensus

    manager.add_transaction_to_pool(Transaction("Alice", "Carol", 1.0))
    block = manager.create_new_block()
    if block and manager.add_block_to_chain(block):
        print("PoS 出块成功:", block.hash)

    print("余额缓存:", manager.balance_cache)