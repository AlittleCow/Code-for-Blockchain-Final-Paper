"""
区块链完整模拟演示
展示PoW/PoS共识、普通交易、闪电网络通道等功能
"""
import time
from simulation import SimulationData
from core.blockchain_manager import BlockChainManager
from core.transaction import Transaction
from consensus.pow import PowConsensus
from consensus.pos import PosConsensus
from consensus.pow_pool import MiningPool
from ln.channel import PaymentChannel
import hashlib

def print_separator(title: str):
    """打印分隔符"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)

def print_balances(manager: BlockChainManager, title: str, addresses: list = None):
    """打印余额信息"""
    print(f"\n💰 {title}")
    if addresses is None:
        addresses = list(manager.balance_cache.keys())
    
    for addr in addresses:
        balance = manager.balance_cache.get(addr, 0.0)
        print(f"  {addr}: {balance:.2f} 币")

def simulate_pow_mining(sim_data: SimulationData):
    """模拟PoW挖矿"""
    print_separator("PoW 挖矿模拟")
    
    # 创建PoW共识 - 使用正确的参数名
    pow_consensus = PowConsensus(target_block_time_sec=10, initial_difficulty=3, miner_address="MinerA")
    manager = BlockChainManager(pow_consensus, mining_reward=50.0)
    
    # 初始化余额
    manager.balance_cache = sim_data.initialize_balances()
    print_balances(manager, "初始余额", list(sim_data.users.keys())[:5])
    
    # 添加一些交易到池中
    transactions = sim_data.generate_random_transactions(8)
    for tx in transactions[:5]:
        manager.add_transaction_to_pool(tx)
        print(f"📝 添加交易: {tx.sender} -> {tx.recipient}, {tx.amount} 币")
    
    # 单个矿工挖矿
    print(f"\n⛏️  开始PoW挖矿 (难度: {pow_consensus.difficulty})")
    start_time = time.time()
    block = manager.create_new_block()
    mining_time = time.time() - start_time
    
    if block and manager.add_block_to_chain(block):
        print(f"✅ 挖矿成功! 耗时: {mining_time:.2f}秒")
        print(f"📦 区块 #{block.index}: {len(block.transactions)} 笔交易")
        print(f"🎯 Nonce: {block.nonce}, Hash: {block.hash[:16]}...")
        
        # 显示挖矿奖励
        coinbase_tx = block.transactions[0]
        print(f"🏆 挖矿奖励: {coinbase_tx.recipient} 获得 {coinbase_tx.amount} 币")
    
    print_balances(manager, "挖矿后余额", list(sim_data.users.keys())[:5])
    return manager

def simulate_pow_pool_mining(sim_data: SimulationData):
    """模拟PoW矿池竞争挖矿"""
    print_separator("PoW 矿池竞争挖矿")
    
    pow_consensus = PowConsensus(target_block_time_sec=10, initial_difficulty=3, miner_address="PoolMiner")
    manager = BlockChainManager(pow_consensus, mining_reward=50.0)
    manager.balance_cache = sim_data.initialize_balances()
    
    # 添加交易
    transactions = sim_data.generate_random_transactions(6)
    for tx in transactions[:4]:
        manager.add_transaction_to_pool(tx)
    
    # 创建矿池 - 传入必需的参数
    mining_pool = MiningPool(manager, pow_consensus)
    for name, info in sim_data.miners.items():
        mining_pool.add_miner(name, info["hashrate"])
    
    print(f"🏭 矿池信息: {len(mining_pool.miners)} 个矿工")
    for miner in mining_pool.miners:
        print(f"  {miner.name}: 算力 {miner.hash_power}")
    
    # 矿池挖矿
    print(f"\n⚡ 开始矿池竞争挖矿...")
    start_time = time.time()
    block = mining_pool.mine_once()
    mining_time = time.time() - start_time
    
    if block and manager.add_block_to_chain(block):
        print(f"🏆 获胜矿工: {block.transactions[0].recipient}")
        print(f"⏱️  挖矿耗时: {mining_time:.2f}秒")
        print(f"📦 区块 #{block.index}: Nonce={block.nonce}")
        
        # 显示矿工奖励
        coinbase_tx = block.transactions[0]
        print(f"💰 挖矿奖励: {coinbase_tx.recipient} 获得 {coinbase_tx.amount} 币")
    else:
        print("❌ 矿池挖矿失败")
    
    return manager

def simulate_pos_consensus(sim_data: SimulationData):
    """模拟PoS共识"""
    print_separator("PoS 共识模拟")
    
    # 创建PoS共识 - 只传入validators_stake参数
    pos_consensus = PosConsensus(sim_data.validators)
    manager = BlockChainManager(pos_consensus, mining_reward=30.0)
    manager.balance_cache = sim_data.initialize_balances()
    
    print_balances(manager, "验证者质押金", list(sim_data.validators.keys()))
    
    # 添加交易
    transactions = sim_data.generate_random_transactions(6)
    for tx in transactions[:4]:
        manager.add_transaction_to_pool(tx)
        print(f"📝 添加交易: {tx.sender} -> {tx.recipient}, {tx.amount} 币")
    
    # PoS出块
    print(f"\n🏛️  开始PoS共识...")
    block = manager.create_new_block()
    
    if block and manager.add_block_to_chain(block):
        print(f"✅ PoS区块创建成功!")
        print(f"📦 区块 #{block.index}: 验证者 {block.validator_id}")
        print(f"🎯 区块哈希: {block.hash[:16]}...")
        
        # 显示验证者奖励
        reward_tx = block.transactions[0]
        print(f"🏆 验证奖励: {reward_tx.recipient} 获得 {reward_tx.amount} 币")
    
    print_balances(manager, "PoS共识后余额", list(sim_data.validators.keys()))
    return manager

def simulate_lightning_network(sim_data: SimulationData, manager: BlockChainManager):
    """模拟闪电网络"""
    print_separator("闪电网络模拟")
    
    # 确保用户有足够余额
    for user, amount in sim_data.users.items():
        if user not in manager.balance_cache:
            manager.balance_cache[user] = amount
    
    print_balances(manager, "开启通道前余额", ["Alice", "Bob", "Charlie", "Diana"])
    
    # 创建闪电网络通道
    channels = []
    ln_transactions = sim_data.generate_ln_transactions()
    
    for ln_tx in ln_transactions:
        if ln_tx["type"] == "ln_open":
            print(f"\n⚡ 开启闪电网络通道: {ln_tx['channel_id']}")
            channel = PaymentChannel(
                ln_tx["party_a"], 
                ln_tx["party_b"], 
                ln_tx["amount_a"], 
                ln_tx["amount_b"], 
                manager
            )
            
            if channel.open_channel():
                channels.append(channel)
                print(f"✅ 通道开启成功: {ln_tx['party_a']} <-> {ln_tx['party_b']}")
                print(f"🔒 锁定资金: {ln_tx['party_a']}({ln_tx['amount_a']}) + {ln_tx['party_b']}({ln_tx['amount_b']})")
            
            break  # 只演示第一个通道
    
    if channels:
        channel = channels[0]
        print(f"\n💸 通道内转账演示:")
        
        # 模拟几笔通道内转账
        transfers = [
            (-30, 30),   # Alice转给Bob 30
            (20, -20),   # Bob转给Alice 20
            (-15, 15)    # Alice转给Bob 15
        ]
        
        for delta_a, delta_b in transfers:
            if channel.update_state(delta_a, delta_b):
                sender = channel.state.party_a if delta_a < 0 else channel.state.party_b
                receiver = channel.state.party_b if delta_a < 0 else channel.state.party_a
                amount = abs(delta_a)
                print(f"  💰 {sender} -> {receiver}: {amount} 币")
                print(f"     余额: {channel.state.party_a}={channel.state.balance_a:.1f}, {channel.state.party_b}={channel.state.balance_b:.1f}")
        
        # 验证通道完整性
        print(f"\n🔍 通道完整性验证: {'✅ 通过' if channel.validate_channel_integrity() else '❌ 失败'}")
        
        # 关闭通道
        print(f"\n🔐 关闭闪电网络通道...")
        channel.close_channel()
        print(f"✅ 通道关闭，资金返还主链")
    
    print_balances(manager, "闪电网络演示后余额", ["Alice", "Bob", "Charlie", "Diana"])

def main():
    """主函数"""
    print_separator("区块链完整模拟演示")
    
    # 初始化模拟数据
    sim_data = SimulationData()
    sim_data.print_simulation_summary()
    
    # 1. PoW挖矿演示
    pow_manager = simulate_pow_mining(sim_data)
    
    # 2. PoW矿池竞争演示
    pool_manager = simulate_pow_pool_mining(sim_data)
    
    # 3. PoS共识演示
    pos_manager = simulate_pos_consensus(sim_data)
    
    # 4. 闪电网络演示
    simulate_lightning_network(sim_data, pos_manager)
    
    # 5. 最终统计
    print_separator("模拟完成统计")
    print(f"📊 PoW链长度: {len(pow_manager.chain)} 个区块")
    print(f"📊 PoW矿池链长度: {len(pool_manager.chain)} 个区块")
    print(f"📊 PoS链长度: {len(pos_manager.chain)} 个区块")
    print(f"📊 总交易数: {pow_manager.network_stats['total_transactions'] + pool_manager.network_stats['total_transactions'] + pos_manager.network_stats['total_transactions']}")
    
    print(f"\n🎉 区块链模拟演示完成!")
    print(f"✅ 展示了PoW挖矿、矿池竞争、PoS共识和闪电网络功能")


    """
    print_separator("实验 A：共识效率对比")
    pow_consensus_a = PowConsensus(target_block_time_sec=10, initial_difficulty=3, miner_address="MinerA")
    pos_consensus_a = PosConsensus(sim_data.validators)
    pow_m_a = BlockChainManager(pow_consensus_a, mining_reward=50.0)
    pos_m_a = BlockChainManager(pos_consensus_a, mining_reward=30.0)
    pow_m_a.balance_cache = sim_data.initialize_balances()
    pos_m_a.balance_cache = sim_data.initialize_balances()
    for tx in sim_data.generate_random_transactions(8)[:5]:
        pow_m_a.add_transaction_to_pool(tx)
        pos_m_a.add_transaction_to_pool(tx)
    t0 = time.time(); blk_pow = pow_m_a.create_new_block(); pow_m_a.add_block_to_chain(blk_pow); pow_block_time = time.time() - t0
    t1 = time.time(); blk_pos = pos_m_a.create_new_block(); pos_m_a.add_block_to_chain(blk_pos); pos_block_time = time.time() - t1
    bulk_txs = sim_data.generate_100_transactions()
    for tx in bulk_txs:
        pow_m_a.add_transaction_to_pool(tx)
        pos_m_a.add_transaction_to_pool(tx)
    t2 = time.time(); blk_pow100 = pow_m_a.create_new_block(); pow_m_a.add_block_to_chain(blk_pow100); pow_100_time = time.time() - t2
    t3 = time.time(); blk_pos100 = pos_m_a.create_new_block(); pos_m_a.add_block_to_chain(blk_pos100); pos_100_time = time.time() - t3
    print(f"PoW出块耗时: {pow_block_time:.4f} 秒")
    print(f"PoS出块耗时: {pos_block_time:.4f} 秒")
    print(f"PoW处理100笔耗时: {pow_100_time:.4f} 秒")
    print(f"PoS处理100笔耗时: {pos_100_time:.4f} 秒")
    try:
        import matplotlib.pyplot as plt
        labels = ["PoW 出块", "PoS 出块", "PoW 处理100笔", "PoS 处理100笔"]
        values = [pow_block_time, pos_block_time, pow_100_time, pos_100_time]
        colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]
        plt.figure(figsize=(9, 4))
        plt.bar(labels, values, color=colors)
        plt.ylabel("秒")
        plt.title("PoW vs PoS 交易确认时间对比")
        plt.tight_layout()
        plt.savefig("结课论文代码版二/consensus_time_bar.png")
        print("柱状图已保存: 结课论文代码版二/consensus_time_bar.png")
    except Exception as e:
        print(f"柱状图未生成: {e}")
    """
    """
    print_separator("实验 B：闪电网络优势分析")
    pow_m_b = BlockChainManager(PowConsensus(target_block_time_sec=10, initial_difficulty=3, miner_address="MinerB"), mining_reward=50.0)
    pow_m_b.balance_cache = sim_data.initialize_balances()
    fee_onchain = 0.2
    onchain_times = []
    total_fee_onchain = 0.0
    for i in range(10):
        s, r = ("Alice", "Bob") if i % 2 == 0 else ("Bob", "Alice")
        tx = Transaction(s, r, 10.0, fee=fee_onchain)
        pow_m_b.add_transaction_to_pool(tx)
        tb = time.time(); blk_b = pow_m_b.create_new_block(); pow_m_b.add_block_to_chain(blk_b); onchain_times.append(time.time() - tb)
        total_fee_onchain += fee_onchain
    pos_m_b = BlockChainManager(PosConsensus(sim_data.validators), mining_reward=30.0)
    pos_m_b.balance_cache = sim_data.initialize_balances()
    channel = PaymentChannel("Alice", "Bob", 100.0, 100.0, pos_m_b)
    channel.open_channel()
    offchain_times = []
    for i in range(10):
        da = -10.0 if i % 2 == 0 else 10.0
        db = 10.0 if i % 2 == 0 else -10.0
        ts = time.time(); channel.update_state(da, db); offchain_times.append(time.time() - ts)
    channel.close_channel()
    total_fee_ln = 0.2
    avg_on = sum(onchain_times) / len(onchain_times)
    avg_off = sum(offchain_times) / len(offchain_times)
    print("方案                | 区块数 | 总手续费 | 平均确认时间(秒)")
    print("-------------------|--------|----------|-----------------")
    print(f"传统链上转账       |   10   |   {total_fee_onchain:.2f}   |   {avg_on:.4f}")
    print(f"闪电网络通道       |    1   |   {total_fee_ln:.2f}   |   {avg_off:.4f}")
    """
    
    print_separator("实验 C：安全性测试")
    pos_m_c = BlockChainManager(PosConsensus(sim_data.validators), mining_reward=30.0)
    pos_m_c.balance_cache = sim_data.initialize_balances()
    for tx in sim_data.generate_random_transactions(6)[:4]:
        pos_m_c.add_transaction_to_pool(tx)
    blk_c = pos_m_c.create_new_block(); pos_m_c.add_block_to_chain(blk_c)
    try:
        pos_m_c.chain[1].transactions[1].amount += 99.0
        print("已篡改一笔历史交易金额")
        pos_m_c.verify_chain_integrity()
        print("整链校验通过")
    except Exception as e:
        print(f"整链校验失败: {e}")
    ch2 = PaymentChannel("Alice", "Bob", 50.0, 50.0, pos_m_c)
    ch2.open_channel()
    preimage = "secret_timeout"
    hval = hashlib.sha256(preimage.encode()).hexdigest()
    ch2.add_htlc("Alice", "Bob", 20.0, hval, 50)
    tcount = ch2.timeout_htlcs(100)
    print(f"超时未履约处理数量: {tcount}")
    print(f"通道余额: Alice={ch2.state.balance_a:.2f}, Bob={ch2.state.balance_b:.2f}")
    ch2.close_channel()
    

if __name__ == "__main__":
    main()
