"""
可选模块：并行竞争出块
"""


import time
import threading
import copy
from typing import Dict, List, Optional
from core.block import Block
from core.transaction import Transaction
from consensus.pow import PowConsensus

class Miner:
    def __init__(self, name: str, hash_power: int):
        self.name = name
        self.hash_power = hash_power
        self.is_mining = False

class MiningPool:
    def __init__(self, manager, consensus: PowConsensus):
        self.manager = manager
        self.consensus = consensus
        self.miners: List[Miner] = []
        self.is_mining = False

    def add_miner(self, name: str, hash_power: int):
        self.miners.append(Miner(name, hash_power))

    def mine_once(self) -> Optional[Block]:
        if not self.miners:
            return None
        pending = self.manager.get_pending_transactions()
        # coinbase 先临时写入，获胜后再改为赢家地址
        coinbase = Transaction(sender="System", recipient="TempMiner", amount=self.manager.mining_reward)
        coinbase.signature = "coinbase"
        template_block = Block(index=len(self.manager.chain), previous_hash=self.manager.get_latest_block().hash, transactions=[coinbase] + pending)
        template_block.consensus_type = "pow"
        template_block.difficulty = self.consensus.difficulty

        results = {}
        target_prefix = "0" * template_block.difficulty
        self.is_mining = True
        start = time.time()

        def work(miner: Miner, base_block: Block):
            miner.is_mining = True
            # 每个矿工拷贝一份区块副本
            blk = Block(index=base_block.index, previous_hash=base_block.previous_hash, transactions=copy.deepcopy(base_block.transactions))
            blk.consensus_type = base_block.consensus_type
            blk.difficulty = base_block.difficulty
            # 为每个矿工设置自己的 coinbase 接收地址，并刷新交易ID与 Merkle
            blk.transactions[0].recipient = miner.name
            cb = blk.transactions[0]
            cb.tx_id = cb.calculate_id()
            blk.merkle_root = blk.calculate_merkle_root()
            blk.hash = blk.calculate_hash()
            delay = 1.0 / max(1, miner.hash_power)
            while self.is_mining:
                blk.nonce += 1
                blk.hash = blk.calculate_hash()
                if blk.hash.startswith(target_prefix):
                    results[miner.name] = blk
                    break
                time.sleep(delay)
            miner.is_mining = False

        threads = []
        for m in self.miners:
            t = threading.Thread(target=work, args=(m, template_block))
            threads.append(t)
            t.start()

        winner_name = None
        while self.is_mining:
            if results:
                winner_name = next(iter(results.keys()))
                break
            time.sleep(0.01)

        self.is_mining = False
        for t in threads:
            t.join(timeout=1.0)

        if not winner_name:
            return None

        winning_block = results[winner_name]

        # 统计与难度调整
        mining_time = time.time() - start
        self.manager.network_stats["total_mining_time"] += mining_time
        self.consensus._retarget(mining_time)
        return winning_block
