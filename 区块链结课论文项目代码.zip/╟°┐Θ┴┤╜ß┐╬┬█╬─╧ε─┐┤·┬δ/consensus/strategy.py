from abc import ABC, abstractmethod
from typing import Optional

"""
定义了一个抽象类，用于实现不同的共识机制策略。
"""


class ConsensusStrategy(ABC):
    @abstractmethod
    def propose_block(self, manager) -> Optional["Block"]:
        pass

    @abstractmethod
    def validate_block(self, manager, block: "Block") -> bool:
        pass

    @abstractmethod
    def finalize_block(self, manager, block: "Block") -> None:
        pass