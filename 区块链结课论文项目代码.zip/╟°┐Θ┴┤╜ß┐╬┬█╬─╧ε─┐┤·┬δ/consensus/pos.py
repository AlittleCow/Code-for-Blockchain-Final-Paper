import random
import hashlib
from typing import Dict, Optional
from core.block import Block
from core.transaction import Transaction
from consensus.strategy import ConsensusStrategy

class PosConsensus(ConsensusStrategy):
    def __init__(self, validators_stake: Dict[str, float]):   # 初始化验证。创建一个验证者的字典，每个验证者有一个初始的质押金额
        self.validators_stake = validators_stake  # address -> stake

    def _weighted_choice(self) -> str:              # 加权随机选择一个验证者
        total = sum(self.validators_stake.values())
        r = random.uniform(0, total)
        upto = 0.0
        for addr, stake in self.validators_stake.items():
            upto += stake
            if upto >= r:
                return addr
        return next(iter(self.validators_stake))

    def _create_coinbase(self, manager, validator: str) -> Transaction:   # 创建一个奖励交易，奖励给验证者
        tx = Transaction(sender="System", recipient=validator, amount=manager.mining_reward)
        tx.signature = "pos_reward"  # 奖励交易的特殊签名
        return tx

    def _sign(self, block: Block, validator: str) -> str:
        """
        区块签名机制：
        1. 验证者对区块索引、前一个区块哈希、Merkle根、验证者ID进行拼接。
        2. 对拼接后的字符串进行SHA-256哈希计算，得到签名。（在实际应用中应使用私钥进行加密）
        """
        payload = f"{block.index}|{block.previous_hash}|{block.merkle_root}|{validator}"
        return hashlib.sha256(payload.encode()).hexdigest()


    def propose_block(self, manager) -> Optional[Block]:
        validator = self._weighted_choice()         # 随机选择一个验证者
        pending = manager.get_pending_transactions()  # 获取待处理交易
        coinbase = self._create_coinbase(manager, validator) # 创建奖励交易
        txs = [coinbase] + pending  # 奖励交易 + 待处理交易
        block = Block(index=len(manager.chain), previous_hash=manager.get_latest_block().hash, transactions=txs)
        block.consensus_type = "pos"  # 标记为 PoS 共识
        block.validator_id = validator
        block.validator_sig = self._sign(block, validator)  # 验证者对区块进行签名
        # PoS 不使用 nonce/difficulty
        block.nonce = 0
        block.difficulty = 0
        block.hash = block.calculate_hash()
        return block

    def validate_block(self, manager, block: Block) -> bool:
        if block.consensus_type != "pos":
            return False
        if not block.is_valid_base():
            return False
        expected = self._sign(block, block.validator_id)
        return expected == block.validator_sig

    def finalize_block(self, manager, block: Block) -> None:    #区块上链之后将奖励交易中的金额奖励给验证者
        manager._credit(block.transactions[0].recipient, manager.mining_reward)