import time
from typing import Optional
from core.block import Block
from core.transaction import Transaction
from consensus.strategy import ConsensusStrategy

class PowConsensus(ConsensusStrategy):
    def __init__(self, target_block_time_sec: int = 10, initial_difficulty: int = 2, miner_address: str = "MinerA"):
        self.target_block_time_sec = target_block_time_sec
        self.difficulty = initial_difficulty
        self.miner_address = miner_address

    def _create_coinbase(self, manager) -> Transaction:
        tx = Transaction(sender="System", recipient=self.miner_address, amount=manager.mining_reward)
        tx.signature = "coinbase"
        return tx

    def propose_block(self, manager) -> Optional[Block]:
        pending = manager.get_pending_transactions()
        coinbase = self._create_coinbase(manager)
        txs = [coinbase] + pending
        block = Block(index=len(manager.chain), previous_hash=manager.get_latest_block().hash, transactions=txs)
        block.consensus_type = "pow"
        block.difficulty = self.difficulty
        start = time.time()
        target_prefix = "0" * block.difficulty
        while not block.hash.startswith(target_prefix):
            block.nonce += 1
            block.hash = block.calculate_hash()
        # 难度调整（极简）：按上一个区块时间移动
        mining_time = time.time() - start
        manager.network_stats["total_mining_time"] += mining_time
        self._retarget(mining_time)
        return block

    def _retarget(self, mining_time: float):
        if mining_time < self.target_block_time_sec * 0.8:
            self.difficulty = min(self.difficulty + 1, 8)
        elif mining_time > self.target_block_time_sec * 1.2:
            self.difficulty = max(self.difficulty - 1, 1)

    def validate_block(self, manager, block: Block) -> bool:
        if block.consensus_type != "pow":
            return False
        if not block.is_valid_base():
            return False
        return block.hash.startswith("0" * block.difficulty)

    def finalize_block(self, manager, block: Block) -> None:
        # 简化余额：给矿工记账
        manager._credit(block.transactions[0].recipient, manager.mining_reward)