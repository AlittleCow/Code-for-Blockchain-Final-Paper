from enum import Enum

class TransactionType(Enum):
    REGULAR = "regular"                     #常规交易
    CONTRACT_DEPLOY = "contract_deploy"     #智能合约部署交易
    CONTRACT_CALL = "contract_call"         #智能合约调用交易
