from typing import List, Optional
from .block import Block
from .transaction import Transaction

class BlockChainManager:
    def __init__(self, consensus_strategy, mining_reward: float = 10.0):
        self.chain: List[Block] = []                           #区块链存储
        self.transaction_pool: List[Transaction] = []          #交易池存储
        self.consensus = consensus_strategy                    #共识机制策略(具体实现在consensus目录下)
        self.mining_reward = mining_reward                     #pow下的挖矿奖励
        self.balance_cache = {}                                #余额缓存
        self.network_stats = {
            "total_transactions": 0,
            "total_blocks": 0,
            "total_mining_time": 0.0,
        }
        self._init_genesis()                                  #建立创世区块
    
        """
        创世区块的作用是初始化区块链，设置初始余额和交易记录，统一区块链的初始节点
        """

    def _init_genesis(self):
        genesis_tx = Transaction(sender="System", recipient="Genesis", amount=0.0)
        block = Block(index=0, previous_hash="0", transactions=[genesis_tx])
        block.consensus_type = "genesis"
        # 设置共识类型后重新计算哈希，保持一致性
        block.hash = block.calculate_hash()
        self.chain.append(block)
        self.network_stats["total_blocks"] = 1

    def get_latest_block(self) -> Block:      
        """
        获取最新的区块
        """
        return self.chain[-1]

    def add_transaction_to_pool(self, tx: Transaction) -> bool:
        """
        将交易添加到交易池
        """
        self.transaction_pool.append(tx)
        self.network_stats["total_transactions"] += 1
        return True

    def get_pending_transactions(self, max_count: Optional[int] = None) -> List[Transaction]:
        """
        获取交易池中的待处理交易,可选择全部或者指定数量
        """
        if max_count is None:
            return list(self.transaction_pool)
        return self.transaction_pool[:max_count]

    def remove_transactions_from_pool(self, txs: List[Transaction]):
        """
        从交易池中移除指定的交易
        """
        ids = {t.tx_id for t in txs}
        self.transaction_pool = [t for t in self.transaction_pool if t.tx_id not in ids]

    def _credit(self, addr: str, amount: float):
        """
        为指定地址增加余额,如果地址不存在则创建，并且初始化为0
        """
        self.balance_cache[addr] = self.balance_cache.get(addr, 0.0) + amount

    def create_new_block(self) -> Optional[Block]:
        return self.consensus.propose_block(self)

    def validate_block(self, block: Block) -> bool:
        if not block.is_valid_base():
            return False
        # 索引与前哈希校验
        if block.index != len(self.chain):
            return False
        if block.previous_hash != self.get_latest_block().hash:
            return False
        return self.consensus.validate_block(self, block)

    def add_block_to_chain(self, block: Block) -> bool:
        if not self.validate_block(block):
            return False
        self.chain.append(block)
        self.consensus.finalize_block(self, block)
        # 移除已确认交易（跳过 coinbase）
        self.remove_transactions_from_pool(block.transactions[1:])
        self.network_stats["total_blocks"] += 1
        return True

    def verify_chain_integrity(self) -> bool:
        for i, block in enumerate(self.chain):
            if not block.is_valid_base():
                raise ValueError(f"区块#{i}基础校验失败：哈希/Merkle/交易内容不一致")
            if i == 0:
                continue
            prev = self.chain[i - 1]
            if block.previous_hash != prev.hash:
                raise ValueError(f"区块#{i}前一区块哈希不匹配")
            if not self.consensus.validate_block(self, block):
                raise ValueError(f"区块#{i}共识校验失败")
        return True
