import time      #用于获取交易创建的时间戳
import hashlib   #用于计算交易的哈希值
import json
from typing import Any, Dict
from .types import TransactionType   #导入交易类型枚举

class Transaction:
    def __init__(self, sender: str, recipient: str, amount: float,
                 tx_type: TransactionType = TransactionType.REGULAR, fee: float = 0.0):
        self.sender = sender          #交易发送方地址
        self.recipient = recipient    #交易接收方地址
        self.amount = amount          #交易金额
        self.tx_type = tx_type        #交易类型（默认为常规交易）
        self.fee = fee                #交易手续费
        self.timestamp = time.time()  #交易创建时间戳
        self.signature = ""  # 简化签名
        self.is_verified = True  # 简化验证
        self.tx_id = self.calculate_hash()  #交易哈希值（根据交易内容计算）

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sender": self.sender,
            "recipient": self.recipient,
            "amount": self.amount,
            "tx_type": self.tx_type.value,
            "fee": self.fee,
            "timestamp": self.timestamp,
            "signature": self.signature,
        }

    def calculate_hash(self) -> str:
        # 计算交易的哈希值（根据交易内容计算）
        payload = json.dumps(self.to_dict(), sort_keys=True)
        return hashlib.sha256(payload.encode()).hexdigest()

    def calculate_id(self) -> str:
        data = self.to_dict().copy()
        data["signature"] = ""
        payload = json.dumps(data, sort_keys=True)
        return hashlib.sha256(payload.encode()).hexdigest()
