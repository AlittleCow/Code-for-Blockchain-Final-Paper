import time
import hashlib
import json
from typing import List, Dict, Any
from .transaction import Transaction

class Block:
    def __init__(self, index: int, previous_hash: str, transactions: List[Transaction]):
        self.index = index
        self.timestamp = time.time()
        self.previous_hash = previous_hash
        self.transactions = transactions or []
        # 先初始化共识相关字段，避免 calculate_hash 访问不存在属性
        self.consensus_type = ""               #共识机制类型（pow或pos）
        self.validator_id = ""                 #验证者标识，在Pos共识机制中使用
        self.validator_sig = ""                #验证者签名
        self.merkle_root = self.calculate_merkle_root()         #交易数据的Merkle根哈希
        self.nonce = 0            #随机数字，用于Pow的共识机制
        self.difficulty = 0       #当前区块的挖矿难度
        self.hash = self.calculate_hash()

    def calculate_merkle_root(self) -> str:
        if not self.transactions:
            return hashlib.sha256(b"").hexdigest()
        tx_hashes = [tx.tx_id for tx in self.transactions]
        if len(tx_hashes) == 1:
            return tx_hashes[0]
        while len(tx_hashes) > 1:
            if len(tx_hashes) % 2 == 1:
                tx_hashes.append(tx_hashes[-1])
            next_level = []
            for i in range(0, len(tx_hashes), 2):
                pair = tx_hashes[i] + tx_hashes[i + 1]
                next_level.append(hashlib.sha256(pair.encode()).hexdigest())
            tx_hashes = next_level
        return tx_hashes[0]

    def calculate_hash(self) -> str:
        header = {
            "index": self.index,
            "timestamp": self.timestamp,
            "previous_hash": self.previous_hash,
            "merkle_root": self.merkle_root,
            "nonce": self.nonce,
            "difficulty": self.difficulty,
            "consensus_type": self.consensus_type,
            "validator_id": self.validator_id,
        }
        return hashlib.sha256(json.dumps(header, sort_keys=True).encode()).hexdigest()

    def is_valid_base(self) -> bool:
        # 通用验证：哈希与Merkle，不包含具体共识校验
        if self.hash != self.calculate_hash():
            return False
        if self.merkle_root != self.calculate_merkle_root():
            return False
        for tx in self.transactions:
            if not tx.is_verified:
                return False
            if tx.tx_id != tx.calculate_id():
                return False
        return True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "previous_hash": self.previous_hash,
            "hash": self.hash,
            "merkle_root": self.merkle_root,
            "nonce": self.nonce,
            "difficulty": self.difficulty,
            "consensus_type": self.consensus_type,
            "validator_id": self.validator_id,
            "validator_sig": self.validator_sig,
            "transactions": [tx.to_dict() for tx in self.transactions],
        }
