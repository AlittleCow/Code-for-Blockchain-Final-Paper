"""
区块链模拟数据生成器
生成用户、矿工、验证者和交易数据
"""
import random
from typing import Dict, List, Tuple
from core.transaction import Transaction

class SimulationData:
    def __init__(self):
        # 普通用户及其初始余额
        self.users = {
            "Alice": 1000.0,
            "Bob": 800.0,
            "Charlie": 1200.0,
            "Diana": 600.0,
            "Eve": 900.0,
            "Frank": 750.0,
            "Grace": 1100.0,
            "Henry": 500.0
        }
        
        # PoW矿工及其算力（哈希率）
        self.miners = {
            "Miner_Alpha": {"hashrate": 100, "address": "miner_alpha_addr"},
            "Miner_Beta": {"hashrate": 80, "address": "miner_beta_addr"},
            "Miner_Gamma": {"hashrate": 120, "address": "miner_gamma_addr"},
            "Miner_Delta": {"hashrate": 90, "address": "miner_delta_addr"},
            "Miner_Epsilon": {"hashrate": 110, "address": "miner_epsilon_addr"}
        }
        
        # PoS验证者及其质押金
        self.validators = {
            "ValidatorA": 2000.0,
            "ValidatorB": 1500.0,
            "ValidatorC": 2500.0,
            "ValidatorD": 1800.0,
            "ValidatorE": 2200.0
        }
        
        # 闪电网络通道配置
        self.ln_channels = [
            {"party_a": "Alice", "party_b": "Bob", "amount_a": 200.0, "amount_b": 150.0},
            {"party_a": "Charlie", "party_b": "Diana", "amount_a": 300.0, "amount_b": 200.0},
            {"party_a": "Eve", "party_b": "Frank", "amount_a": 250.0, "amount_b": 180.0}
        ]
    
    def generate_random_transactions(self, count: int = 20) -> List[Transaction]:
        """生成随机交易"""
        transactions = []
        user_list = list(self.users.keys())
        
        for _ in range(count):
            sender = random.choice(user_list)
            receiver = random.choice([u for u in user_list if u != sender])
            amount = round(random.uniform(10, 100), 2)
            
            tx = Transaction(sender=sender, recipient=receiver, amount=amount)
            transactions.append(tx)
        
        return transactions
    
    def generate_ln_transactions(self) -> List[Dict]:
        """生成闪电网络相关交易"""
        ln_transactions = []
        
        # 为每个通道生成开启、转账、关闭交易
        for i, channel in enumerate(self.ln_channels):
            # 通道开启交易
            ln_transactions.append({
                "type": "ln_open",
                "channel_id": f"channel_{i+1}",
                "party_a": channel["party_a"],
                "party_b": channel["party_b"],
                "amount_a": channel["amount_a"],
                "amount_b": channel["amount_b"]
            })
            
            # 通道内转账（3-5笔）
            transfer_count = random.randint(3, 5)
            for _ in range(transfer_count):
                if random.choice([True, False]):
                    sender, receiver = channel["party_a"], channel["party_b"]
                else:
                    sender, receiver = channel["party_b"], channel["party_a"]
                
                amount = round(random.uniform(5, 50), 2)
                ln_transactions.append({
                    "type": "ln_transfer",
                    "channel_id": f"channel_{i+1}",
                    "sender": sender,
                    "receiver": receiver,
                    "amount": amount
                })
            
            # 通道关闭交易
            ln_transactions.append({
                "type": "ln_close",
                "channel_id": f"channel_{i+1}",
                "party_a": channel["party_a"],
                "party_b": channel["party_b"]
            })
        
        return ln_transactions

    def generate_100_transactions(self) -> List[Transaction]:
        return self.generate_random_transactions(100)
    
    def get_all_addresses(self) -> List[str]:
        """获取所有地址列表"""
        addresses = []
        addresses.extend(self.users.keys())
        addresses.extend([miner["address"] for miner in self.miners.values()])
        addresses.extend(self.validators.keys())
        return addresses
    
    def initialize_balances(self) -> Dict[str, float]:
        """初始化所有地址的余额"""
        balances = {}
        
        # 普通用户余额
        balances.update(self.users)
        
        # 矿工初始余额（较少，主要靠挖矿奖励）
        for miner_info in self.miners.values():
            balances[miner_info["address"]] = 100.0
        
        # 验证者余额（包含质押金）
        balances.update(self.validators)
        
        return balances
    
    def print_simulation_summary(self):
        """打印模拟数据摘要"""
        print("=== 区块链模拟数据摘要 ===")
        print(f"\n👥 普通用户 ({len(self.users)}人):")
        for user, balance in self.users.items():
            print(f"  {user}: {balance} 币")
        
        print(f"\n⛏️  PoW矿工 ({len(self.miners)}人):")
        for name, info in self.miners.items():
            print(f"  {name}: 算力={info['hashrate']}, 地址={info['address']}")
        
        print(f"\n🏛️  PoS验证者 ({len(self.validators)}人):")
        for validator, stake in self.validators.items():
            print(f"  {validator}: 质押金={stake} 币")
        
        print(f"\n⚡ 闪电网络通道 ({len(self.ln_channels)}个):")
        for i, channel in enumerate(self.ln_channels):
            print(f"  通道{i+1}: {channel['party_a']}({channel['amount_a']}) <-> {channel['party_b']}({channel['amount_b']})")
        
        total_supply = sum(self.initialize_balances().values())
        print(f"\n💰 总供应量: {total_supply} 币")

if __name__ == "__main__":
    # 测试模拟数据生成
    sim = SimulationData()
    sim.print_simulation_summary()
    
    print("\n=== 随机交易样例 ===")
    random_txs = sim.generate_random_transactions(5)
    for i, tx in enumerate(random_txs):
        print(f"交易{i+1}: {tx.sender} -> {tx.recipient}, 金额: {tx.amount}")
    
    print("\n=== 闪电网络交易样例 ===")
    ln_txs = sim.generate_ln_transactions()
    for i, tx in enumerate(ln_txs[:8]):  # 只显示前8个
        print(f"LN交易{i+1}: {tx}")
