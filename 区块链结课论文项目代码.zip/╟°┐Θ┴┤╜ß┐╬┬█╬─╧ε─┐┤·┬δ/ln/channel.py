from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING
import hashlib

if TYPE_CHECKING:
    from core.blockchain_manager import BlockChainManager

@dataclass
class ChannelState:
    party_a: str            #参与方a的地址
    party_b: str            #参与方b的地址
    balance_a: float        #参与方a的余额
    balance_b: float        #参与方b的余额
    locked_a: float = 0.0   #参与方a在主链锁定的资金
    locked_b: float = 0.0   #参与方b在主链锁定的资金
    channel_id: str = ""    #通道唯一标识
    timelock_expire: Optional[int] = None  # 区块高度或时间戳
    is_open: bool = False   #通道是否已经开启

@dataclass
class HTLC:
    sender: str
    receiver: str
    amount: float
    hashlock: str                   # sha256(preimage)哈希锁
    timelock_expire: int            # 到期高度或时间戳
    preimage: Optional[str] = None  #解锁密钥
    status: str = "offered"         # offered | fulfilled | timed_out

class PaymentChannel:
    def __init__(self, a: str, b: str, initial_a: float, initial_b: float, blockchain_manager: Optional['BlockChainManager'] = None):
        self.state = ChannelState(a, b, initial_a, initial_b)
        self.commitment_version = 0
        self.htlcs: list[HTLC] = []
        self.blockchain_manager = blockchain_manager
        self.state.channel_id = hashlib.sha256(f"{a}{b}{initial_a}{initial_b}".encode()).hexdigest()[:16]
    
    def open_channel(self) -> bool:
        """开启通道，需要在主链锁定资金"""
        if self.blockchain_manager:
            # 检查主链余额是否足够
            balance_a = self.blockchain_manager.balance_cache.get(self.state.party_a, 0.0)
            balance_b = self.blockchain_manager.balance_cache.get(self.state.party_b, 0.0)
            
            if balance_a < self.state.balance_a or balance_b < self.state.balance_b:
                print(f"余额不足: {self.state.party_a}需要{self.state.balance_a}但只有{balance_a}, {self.state.party_b}需要{self.state.balance_b}但只有{balance_b}")
                return False
            
            # 在主链锁定资金
            self.blockchain_manager.balance_cache[self.state.party_a] -= self.state.balance_a
            self.blockchain_manager.balance_cache[self.state.party_b] -= self.state.balance_b
            self.state.locked_a = self.state.balance_a
            self.state.locked_b = self.state.balance_b
            
            print(f"通道{self.state.channel_id}开启: 锁定资金 {self.state.party_a}:{self.state.locked_a}, {self.state.party_b}:{self.state.locked_b}")
        
        self.state.is_open = True
        self.commitment_version = 1
        return True
    
    def update_state(self, delta_a: float, delta_b: float):
        if not self.state.is_open:
            return False
        new_a = self.state.balance_a + delta_a
        new_b = self.state.balance_b + delta_b
        if new_a < 0 or new_b < 0:
            return False
        self.state.balance_a = new_a
        self.state.balance_b = new_b
        self.commitment_version += 1
        return True
    
    def add_htlc(self, sender: str, receiver: str, amount: float, hashlock: str, timelock_expire: int) -> bool:
        if not self.state.is_open:
            return False
        # 锁定资金：从发送方余额划转到“HTLC 持有”状态（这里简化不单独账户，按履约/超时再结算）
        if sender == self.state.party_a:
            if self.state.balance_a < amount:
                return False
            self.state.balance_a -= amount
        else:
            if self.state.balance_b < amount:
                return False
            self.state.balance_b -= amount
        self.htlcs.append(HTLC(sender, receiver, amount, hashlock, timelock_expire))
        self.commitment_version += 1
        return True
    
    def fulfill_htlc(self, preimage: str, now_height: int) -> bool:
        h = hashlib.sha256(preimage.encode()).hexdigest()
        for htlc in self.htlcs:
            if htlc.status == "offered" and htlc.hashlock == h and now_height < htlc.timelock_expire:
                # 履约成功：资金从 HTLC 转到接收方
                htlc.preimage = preimage
                htlc.status = "fulfilled"
                if htlc.receiver == self.state.party_a:
                    self.state.balance_a += htlc.amount
                else:
                    self.state.balance_b += htlc.amount
                self.commitment_version += 1
                return True
        return False
    
    def timeout_htlcs(self, now_height: int) -> int:
        # 到期未履约：资金退回发送方
        count = 0
        for htlc in self.htlcs:
            if htlc.status == "offered" and now_height >= htlc.timelock_expire:
                htlc.status = "timed_out"
                if htlc.sender == self.state.party_a:
                    self.state.balance_a += htlc.amount
                else:
                    self.state.balance_b += htlc.amount
                count += 1
        if count:
            self.commitment_version += 1
        return count
    
    def close_channel(self):
        """关闭通道，将最终余额返还到主链"""
        if self.blockchain_manager and self.state.is_open:
            # 将通道内余额返还到主链
            self.blockchain_manager.balance_cache[self.state.party_a] += self.state.balance_a
            self.blockchain_manager.balance_cache[self.state.party_b] += self.state.balance_b
            
            print(f"通道{self.state.channel_id}关闭: 返还资金 {self.state.party_a}:{self.state.balance_a}, {self.state.party_b}:{self.state.balance_b}")
            
            # 清零锁定资金
            self.state.locked_a = 0.0
            self.state.locked_b = 0.0
        
        self.state.is_open = False
        return self.state
    
    def get_main_chain_balance(self, address: str) -> float:
        """获取主链余额（用于验证）"""
        if self.blockchain_manager:
            return self.blockchain_manager.balance_cache.get(address, 0.0)
        return 0.0
    
    def validate_channel_integrity(self) -> bool:
        """验证通道完整性，确保资金守恒"""
        if not self.state.is_open:
            return True
        
        # 检查通道内余额总和是否等于锁定资金总和
        channel_total = self.state.balance_a + self.state.balance_b
        locked_total = self.state.locked_a + self.state.locked_b
        
        # 加上所有未结算HTLC的金额
        htlc_total = sum(htlc.amount for htlc in self.htlcs if htlc.status == "offered")
        
        return abs(channel_total + htlc_total - locked_total) < 1e-9  # 浮点数精度容差

if __name__ == "__main__":
    print("=== 闪电网络支付通道测试（集成主链） ===")
    
    # 模拟区块链管理器
    class MockBlockchainManager:
        def __init__(self):
            self.balance_cache = {
                "Alice": 200.0,
                "Bob": 150.0,
                "Charlie": 100.0
            }
    
    blockchain = MockBlockchainManager()
    print(f"主链初始余额: Alice={blockchain.balance_cache['Alice']}, Bob={blockchain.balance_cache['Bob']}")
    
    # 1. 创建支付通道（集成主链）
    print("\n1. 创建支付通道（集成主链）")
    channel = PaymentChannel("Alice", "Bob", 100.0, 50.0, blockchain)
    print(f"通道ID: {channel.state.channel_id}")
    
    # 2. 开启通道（会锁定主链资金）
    print("\n2. 开启通道")
    success = channel.open_channel()
    print(f"开启结果: {'成功' if success else '失败'}")
    print(f"主链余额: Alice={blockchain.balance_cache['Alice']}, Bob={blockchain.balance_cache['Bob']}")
    print(f"通道余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    print(f"锁定资金: Alice={channel.state.locked_a}, Bob={channel.state.locked_b}")
    
    # 3. 验证通道完整性
    print(f"\n3. 通道完整性验证: {'通过' if channel.validate_channel_integrity() else '失败'}")
    
    # 4. 普通转账测试
    print("\n4. 普通转账测试")
    success = channel.update_state(-20.0, 20.0)  # Alice转给Bob 20
    print(f"Alice转给Bob 20: {'成功' if success else '失败'}")
    print(f"通道余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    print(f"完整性验证: {'通过' if channel.validate_channel_integrity() else '失败'}")
    
    # 5. 测试双花防护
    print("\n5. 测试双花防护")
    print(f"Alice主链余额: {channel.get_main_chain_balance('Alice')}")
    print("模拟Alice在主链消费50...")
    blockchain.balance_cache["Alice"] -= 50  # Alice在主链消费
    print(f"Alice主链余额变为: {channel.get_main_chain_balance('Alice')}")
    print("通道内余额不受影响（资金已锁定）")
    print(f"通道余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    
    # 6. HTLC测试
    print("\n6. HTLC测试")
    preimage = "secret123"
    hash_value = hashlib.sha256(preimage.encode()).hexdigest()
    
    success = channel.add_htlc("Alice", "Bob", 30.0, hash_value, 100)
    print(f"Alice向Bob发起HTLC(30): {'成功' if success else '失败'}")
    print(f"通道余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    print(f"完整性验证: {'通过' if channel.validate_channel_integrity() else '失败'}")
    
    # 7. HTLC履约
    print("\n7. HTLC履约")
    success = channel.fulfill_htlc(preimage, 50)
    print(f"Bob履约HTLC: {'成功' if success else '失败'}")
    print(f"通道余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    print(f"完整性验证: {'通过' if channel.validate_channel_integrity() else '失败'}")
    
    # 8. 关闭通道（资金返还主链）
    print("\n8. 关闭通道")
    final_state = channel.close_channel()
    print(f"主链最终余额: Alice={blockchain.balance_cache['Alice']}, Bob={blockchain.balance_cache['Bob']}")
    print(f"通道状态: {'开启' if final_state.is_open else '关闭'}")
    
    # 9. 总结
    print("\n9. 防双花机制总结:")
    print("✓ 开启通道时锁定主链资金")
    print("✓ 通道运行期间主链资金不可用")
    print("✓ 通道内余额独立于主链变化")
    print("✓ 关闭通道时资金返还主链")
    print("✓ 完整性验证确保资金守恒")
    print(f"HTLC数量: {len(channel.htlcs)}")
    
    # 5. HTLC履约测试
    print("\n5. HTLC履约测试")
    success = channel.fulfill_htlc(preimage, 50)  # ，未超时
    print(f"Bob使用密钥履约: {'成功' if success else '失败'}")
    print(f"余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    
    if channel.htlcs:
        htlc = channel.htlcs[0]
        print(f"HTLC状态: {htlc.status}")
    
    # 6. HTLC超时测试
    print("\n6. HTLC超时测试")
    
    # 再创建一个HTLC用于超时测试
    preimage2 = "secret456"
    hash_value2 = hashlib.sha256(preimage2.encode()).hexdigest()
    channel.add_htlc("Bob", "Alice", 15.0, hash_value2, 80)
    print(f"Bob向Alice发起HTLC(15)，超时高度80")
    print(f"余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    
    # 模拟时间过去，高度到达90（超过80）
    timeout_count = channel.timeout_htlcs(90)
    print(f"高度90时超时处理: {timeout_count}个HTLC超时")
    print(f"余额: Alice={channel.state.balance_a}, Bob={channel.state.balance_b}")
    


   







    # 7. 关闭通道
    print("\n7. 关闭通道")
    final_state = channel.close_channel()
    print(f"通道关闭")
    print(f"最终余额: Alice={final_state.balance_a}, Bob={final_state.balance_b}")
    print(f"最终承诺版本: {channel.commitment_version}")
    
    # 8. 显示所有HTLC状态
    print("\n8. HTLC历史记录")
    for i, htlc in enumerate(channel.htlcs):
        print(f"HTLC {i+1}: {htlc.sender}->{htlc.receiver}, 金额={htlc.amount}, 状态={htlc.status}")