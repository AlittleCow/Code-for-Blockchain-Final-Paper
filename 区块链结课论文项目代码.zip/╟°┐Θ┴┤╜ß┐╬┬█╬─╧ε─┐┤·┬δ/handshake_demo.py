import time
import hashlib
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))
from simulation import SimulationData
from core.blockchain_manager import BlockChainManager
from consensus.pos import PosConsensus
from ln.channel import PaymentChannel

def run():
    sim = SimulationData()
    mgr = BlockChainManager(PosConsensus(sim.validators), mining_reward=30.0)
    mgr.balance_cache = sim.initialize_balances()

    print("=== HTLC 握手与履约可视化 ===")
    print(f"主链余额: Alice={mgr.balance_cache['Alice']:.1f}, Bob={mgr.balance_cache['Bob']:.1f}")

    ch = PaymentChannel("Alice", "Bob", 100.0, 100.0, mgr)
    assert ch.open_channel()
    print(f"开启通道: 锁定 Alice={ch.state.locked_a:.1f}, Bob={ch.state.locked_b:.1f}")
    print(f"通道余额: Alice={ch.state.balance_a:.1f}, Bob={ch.state.balance_b:.1f}")

    print("\n🔐 握手阶段：交换哈希锁并记录")
    preimage_a = "ln_preimage_A"
    preimage_b = "ln_preimage_B"
    h_a = hashlib.sha256(preimage_a.encode()).hexdigest()
    h_b = hashlib.sha256(preimage_b.encode()).hexdigest()
    print(f"Alice -> Bob 提供哈希锁: {h_a}")
    ch.add_htlc("Alice", "Bob", 12.0, h_a, 50)
    print(f"Bob -> Alice 提供哈希锁: {h_b}")
    ch.add_htlc("Bob", "Alice", 8.0, h_b, 50)
    print(f"通道余额(扣除在途): Alice={ch.state.balance_a:.1f}, Bob={ch.state.balance_b:.1f}")

    print("\n🗝️ 揭示原像并履约")
    ok1 = ch.fulfill_htlc(preimage_a, 10)
    ok2 = ch.fulfill_htlc(preimage_b, 10)
    print(f"Alice→Bob 履约={ok1}, Bob→Alice 履约={ok2}")
    print(f"履约后余额: Alice={ch.state.balance_a:.1f}, Bob={ch.state.balance_b:.1f}")

    print("\n💸 后续通道内互转")
    txs = [(-30, 30), (20, -20), (-15, 15)]
    for da, db in txs:
        ts = time.time()
        ch.update_state(da, db)
        elapsed = time.time() - ts
        sender = ch.state.party_a if da < 0 else ch.state.party_b
        receiver = ch.state.party_b if da < 0 else ch.state.party_a
        print(f"  {sender} -> {receiver}: {abs(da):.1f} 币, 用时 {elapsed:.6f}s")
        print(f"  余额: Alice={ch.state.balance_a:.1f}, Bob={ch.state.balance_b:.1f}")

    print("\n🔍 资金守恒校验")
    ok = ch.validate_channel_integrity()
    print(f"完整性: {ok}")

    print("\n🔐 关闭通道并返还主链")
    ch.close_channel()
    print(f"主链余额: Alice={mgr.balance_cache['Alice']:.1f}, Bob={mgr.balance_cache['Bob']:.1f}")

if __name__ == "__main__":
    run()
