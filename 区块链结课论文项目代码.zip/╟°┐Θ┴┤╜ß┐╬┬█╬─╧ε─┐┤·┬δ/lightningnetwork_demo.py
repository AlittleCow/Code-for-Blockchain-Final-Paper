import time
import os
import sys
import hashlib
sys.path.insert(0, os.path.dirname(__file__))
from simulation import SimulationData
from core.blockchain_manager import BlockChainManager
from consensus.pos import PosConsensus
from ln.channel import PaymentChannel

def run_two_hop_htlc_classic():
    sim = SimulationData()
    mgr = BlockChainManager(PosConsensus(sim.validators), mining_reward=30.0)
    mgr.balance_cache = sim.initialize_balances()

    print("=== 闪电网络经典两跳支付（Alice→Bob→Charlie）===")
    print(f"主链初始余额: Alice={mgr.balance_cache['Alice']:.1f}, Bob={mgr.balance_cache['Bob']:.1f}, Charlie={mgr.balance_cache['Charlie']:.1f}")

    ch_ab = PaymentChannel("Alice", "Bob", 120.0, 80.0, mgr)
    ch_bc = PaymentChannel("Bob", "Charlie", 100.0, 50.0, mgr)
    ch_ab.open_channel(); ch_bc.open_channel()
    print(f"开启通道: AB锁定(A:{ch_ab.state.locked_a:.1f},B:{ch_ab.state.locked_b:.1f}), BC锁定(B:{ch_bc.state.locked_a:.1f},C:{ch_bc.state.locked_b:.1f})")
    print(f"通道余额: AB(A:{ch_ab.state.balance_a:.1f},B:{ch_ab.state.balance_b:.1f}), BC(B:{ch_bc.state.balance_a:.1f},C:{ch_bc.state.balance_b:.1f})")

    preimage = "classic_secret_123"
    h = hashlib.sha256(preimage.encode()).hexdigest()
    print(f"生成原像与哈希锁: H={h}")
    print("步骤1: Alice→Bob 添加HTLC(30, timelock=80)")
    ch_ab.add_htlc("Alice", "Bob", 30.0, h, 80)
    print("步骤2: Bob→Charlie 添加HTLC(30, timellock=50)")
    ch_bc.add_htlc("Bob", "Charlie", 30.0, h, 50)
    print(f"在途扣减后余额: AB(A:{ch_ab.state.balance_a:.1f},B:{ch_ab.state.balance_b:.1f}), BC(B:{ch_bc.state.balance_a:.1f},C:{ch_bc.state.balance_b:.1f})")

    print("步骤3: Charlie揭示原像履约(高度=40)")
    ok_c = ch_bc.fulfill_htlc(preimage, 40)
    print(f"BC履约结果: {ok_c}, 余额(B:{ch_bc.state.balance_a:.1f}, C:{ch_bc.state.balance_b:.1f})")

    print("步骤4: Bob获取原像后在AB链履约(高度=60)")
    ok_b = ch_ab.fulfill_htlc(preimage, 60)
    print(f"AB履约结果: {ok_b}, 余额(A:{ch_ab.state.balance_a:.1f}, B:{ch_ab.state.balance_b:.1f})")

    print(f"完整性校验: AB={ch_ab.validate_channel_integrity()}, BC={ch_bc.validate_channel_integrity()}")
    ch_ab.close_channel(); ch_bc.close_channel()
    print(f"主链返还余额: Alice={mgr.balance_cache['Alice']:.1f}, Bob={mgr.balance_cache['Bob']:.1f}, Charlie={mgr.balance_cache['Charlie']:.1f}")

def run_two_hop_htlc_timeout():
    sim = SimulationData()
    mgr = BlockChainManager(PosConsensus(sim.validators), mining_reward=30.0)
    mgr.balance_cache = sim.initialize_balances()

    print("\n=== 闪电网络两跳支付超时回退（Alice→Bob→Charlie）===")
    ch_ab = PaymentChannel("Alice", "Bob", 80.0, 60.0, mgr)
    ch_bc = PaymentChannel("Bob", "Charlie", 70.0, 50.0, mgr)
    ch_ab.open_channel(); ch_bc.open_channel()

    preimage = "timeout_secret"
    h = hashlib.sha256(preimage.encode()).hexdigest()
    print(f"生成原像与哈希锁: H={h}")
    print("步骤1: Alice→Bob 添加HTLC(25, timelock=60)")
    ch_ab.add_htlc("Alice", "Bob", 25.0, h, 60)
    print("步骤2: Bob→Charlie 添加HTLC(25, timelock=30)")
    ch_bc.add_htlc("Bob", "Charlie", 25.0, h, 30)
    print(f"在途扣减后余额: AB(A:{ch_ab.state.balance_a:.1f},B:{ch_ab.state.balance_b:.1f}), BC(B:{ch_bc.state.balance_a:.1f},C:{ch_bc.state.balance_b:.1f})")

    print("步骤3: 超时未履约，先在BC链回退(高度=100)")
    t_bc = ch_bc.timeout_htlcs(100)
    print(f"BC超时回退数量: {t_bc}, 余额(B:{ch_bc.state.balance_a:.1f}, C:{ch_bc.state.balance_b:.1f})")
    print("步骤4: 无原像，AB链也回退(高度=120)")
    t_ab = ch_ab.timeout_htlcs(120)
    print(f"AB超时回退数量: {t_ab}, 余额(A:{ch_ab.state.balance_a:.1f}, B:{ch_ab.state.balance_b:.1f})")

    print(f"完整性校验: AB={ch_ab.validate_channel_integrity()}, BC={ch_bc.validate_channel_integrity()}")
    ch_ab.close_channel(); ch_bc.close_channel()
    print(f"主链返还余额: Alice={mgr.balance_cache['Alice']:.1f}, Bob={mgr.balance_cache['Bob']:.1f}, Charlie={mgr.balance_cache['Charlie']:.1f}")

def run():
    run_two_hop_htlc_classic()
    run_two_hop_htlc_timeout()

if __name__ == "__main__":
    run()
