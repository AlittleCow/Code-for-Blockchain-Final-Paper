# 结课论文代码版二 实验优化计划

## 总体原则
- 保持现有演示逻辑不变，新增实验段落集中在 `main.py` 末尾。
- 复用现有 `SimulationData`、`BlockChainManager`、`PowConsensus`、`PosConsensus` 与 `PaymentChannel`，避免重构。
- 所有新增统计与可视化均为旁路输出，不影响链状态与原有函数签名。

## 代码结构简析
- 共识层：`consensus/pow.py`（工作量证明）、`consensus/pos.py`（权益证明）、`consensus/pow_pool.py`（矿池并行挖矿）。
- 链管理：`core/blockchain_manager.py` 负责链、交易池、上链与共识回调。
- 区块与交易：`core/block.py`、`core/transaction.py`。
- 闪电网络：`ln/channel.py`，含通道、状态更新、HTLC 与超时处理。
- 演示入口：`main.py`，已有 PoW/矿池/PoS/闪电网络的示例。

## 实验 A：共识效率对比
1. 出块耗时记录
   - 在 `main.py` 新增实验段落，分别构建独立的 PoW/PoS 管理器，向池加入少量交易后各自出块，记录 `time.time()` 差值。
2. 批量交易确认耗时
   - 在 `simulation.py` 新增 `generate_100_transactions()`，并在实验段落分别向 PoW/PoS 写入 100 笔交易，各自出块并统计总确认耗时。
3. 柱状图输出
   - 优先使用 `matplotlib` 绘制柱状图，保存至 `结课论文代码版二/consensus_time_bar.png`；如环境缺库，控制台提示原因，不影响程序运行。

## 实验 B：闪电网络优势分析
1. 主链互转 10 次（慢且贵）
   - 使用 PoW 管理器，每次仅加入一笔 Alice/Bob 互转并立即出块，记录每块耗时，累计手续费（固定费率）。
2. 通道内互转 10 次（秒级且低成本）
   - 使用 `PaymentChannel` 开启通道后连续调用 `update_state` 10 次，记录平均耗时；最终视为 1 笔上链结算，统计一次手续费。
3. 输出对比表
   - 控制台打印表格：方案/区块数/总手续费/平均确认时间。

## 实验 C：安全性测试
1. 不可篡改性验证
   - 在 `core/blockchain_manager.py` 新增 `verify_chain_integrity()`，遍历整链校验哈希、前哈希与共识。
   - 在 `main.py` 中构造含交易的链后，直接修改历史区块中的一笔交易金额，调用验证函数捕获异常，输出错误信息。
2. 闪电网络超时回退
   - 在 `main.py` 中创建通道，加入 HTLC 并模拟超时，调用 `timeout_htlcs` 展示退回数量与余额变化，随后关闭通道。

## 运行与产出
- 运行：`python 结课论文代码版二/main.py`
- 产出：
  - 柱状图：`结课论文代码版二/consensus_time_bar.png`（PoW vs PoS 交易确认时间对比）。
  - 控制台表格：传统链上交易与链下通道的成本/时效对比。
  - 控制台错误输出：历史交易篡改后的整链校验失败信息与 HTLC 超时回退过程。

## 变更概览（最小改动）
- `core/blockchain_manager.py`：新增 `verify_chain_integrity()`，不改动既有逻辑。
- `simulation.py`：新增 `generate_100_transactions()`，不影响原有默认行为。
- `main.py`：仅追加实验段落与必要导入，未更改已存在函数签名与调用顺序。
