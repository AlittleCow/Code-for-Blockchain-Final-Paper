# 演示伪代码总览（论文版）

## main.py 演示流程（简化伪代码）

```
流程：
1. 初始化与概览：加载模拟数据，打印用户/矿工/验证者与通道配置。
2. PoW 挖矿：构建 PoW 管理器，写入少量交易，出块并打印耗时、区块信息与奖励。
3. PoW 矿池：注册多名矿工并行竞争出块（交易池为空也可挖仅含奖励的块），打印赢家与区块信息。
4. PoS 共识：构建 PoS 管理器并加入交易，由验证者加权选举出块，打印验证者与区块哈希。
5. 闪电网络：开启通道（锁定主链资金），在通道内进行多次链下互转；校验资金守恒后关闭通道（返还主链）。
6. 最终统计：打印各链长度与总交易数。

实验（main 中注释保留的代码段）：
A. 共识效率对比：记录 PoW/PoS 出块耗时；生成 100 笔交易后两者确认耗时；保存柱状图。
B. 闪电网络优势：链上 10 次互转（10 区块，统计确认时间/手续费）vs 通道内 10 次互转（秒级确认，最终 1 次上链结算）；输出对比表。
C. 安全性测试：篡改历史交易后整链校验失败（不可篡改性）；HTLC 超时未履约资金回退。
```
  # 1) PoW 挖矿演示
  pow_consensus = PowConsensus(target_block_time_sec=10, initial_difficulty=K, miner_address="MinerA")
  pow_manager = BlockChainManager(pow_consensus, mining_reward=50)
  pow_manager.balance_cache = sim_data.initialize_balances()
  txs = sim_data.generate_random_transactions(N)
  for t in subset(txs): pow_manager.add_transaction_to_pool(t)
  t0 = now(); blk = pow_manager.create_new_block(); elapsed = now()-t0
  if pow_manager.add_block_to_chain(blk):
      print(block info, reward, elapsed)

  # 2) PoW 矿池竞争挖矿
  pool_consensus = PowConsensus(...)
  pool_manager = BlockChainManager(pool_consensus, mining_reward=50)
  pool_manager.balance_cache = sim_data.initialize_balances()
  txs = sim_data.generate_random_transactions(M)
  for t in subset(txs): pool_manager.add_transaction_to_pool(t)
  pool = MiningPool(pool_manager, pool_consensus)
  for name, info in sim_data.miners: pool.add_miner(name, info.hashrate)
  t0 = now(); blk = pool.mine_once(); elapsed = now()-t0
  if blk and pool_manager.add_block_to_chain(blk):
      print(winner miner, block info, elapsed, reward)
  else:
      print("矿池挖矿失败")

  # 3) PoS 共识演示
  pos_consensus = PosConsensus(sim_data.validators)
  pos_manager = BlockChainManager(pos_consensus, mining_reward=30)
  pos_manager.balance_cache = sim_data.initialize_balances()
  txs = sim_data.generate_random_transactions(P)
  for t in subset(txs): pos_manager.add_transaction_to_pool(t)
  blk = pos_manager.create_new_block()
  if pos_manager.add_block_to_chain(blk):
      print(validator, block hash, reward)

  # 4) 闪电网络演示
  ensure users exist in pos_manager.balance_cache
  print_balances(before)
  ln_config = first(sim_data.generate_ln_transactions() where type == "ln_open")
  channel = PaymentChannel(ln_config.party_a, ln_config.party_b, ln_config.amount_a, ln_config.amount_b, pos_manager)
  if channel.open_channel(): print(locked funds)
  transfers = [(-30, 30), (20, -20), (-15, 15)]
  for (da, db) in transfers:
      if channel.update_state(da, db): print(sender->receiver, amount, balances)
  print("完整性校验", channel.validate_channel_integrity())
  channel.close_channel(); print("资金返还主链")
  print_balances(after)

  # 5) 最终统计
  print(pow_manager.chain length, pool_manager.chain length, pos_manager.chain length)
  print(total transactions)

  # 6) 实验 C：安全性测试
  pos_m_c = BlockChainManager(PosConsensus(sim_data.validators), mining_reward=30)
  pos_m_c.balance_cache = sim_data.initialize_balances()
  for t in subset(sim_data.generate_random_transactions(6)): pos_m_c.add_transaction_to_pool(t)
  blk = pos_m_c.create_new_block(); pos_m_c.add_block_to_chain(blk)
  try:
    pos_m_c.chain[1].transactions[1].amount += 99  # 篡改历史交易
    pos_m_c.verify_chain_integrity()                # 逐区块重算哈希/Merkle/交易ID一致性
    print("整链校验通过")                            # 若仍通过，表示校验逻辑需检查
  except Exception as e:
    print("整链校验失败", e)                         # 正确行为：失败并定位区块号
  ch2 = PaymentChannel("Alice", "Bob", 50, 50, pos_m_c)
  ch2.open_channel()
  preimage = "secret_timeout"; hval = sha256(preimage)
  ch2.add_htlc("Alice", "Bob", 20, hval, timelock=50)
  count = ch2.timeout_htlcs(now_height=100)         # 超时回退
  print("超时处理数量", count)
  print("通道余额", ch2.state.balance_a, ch2.state.balance_b)
  ch2.close_channel()
```


要点：
- PoW/PoS 采用策略模式统一 `propose_block/validate_block/finalize_block`；PoW 通过哈希前缀命中，PoS 通过权益加权与签名验证。
- 并行矿池在每个线程内预先设置 coinbase 接收地址并重算交易 ID 与 Merkle，再进行 nonce 求解，避免事后修改造成校验失败。
- 闪电网络演示包含通道开启/链下转账/完整性校验/关闭返还主链。
- 安全性测试通过篡改历史交易后调用整链校验函数，展示不可篡改特性；HTLC 超时回退展示资金安全。

---

## handshake_demo.py（HTLC 握手留痕，简化伪代码）

```
流程：
1. 准备：初始化 PoS 管理器与主链余额，开启 Alice-Bob 通道并打印锁定资金与通道余额。
2. 握手：双方各生成原像与哈希锁，添加两笔 HTLC，打印哈希值与扣减后的通道余额。
3. 履约：在时锁未到期时揭示原像并履约，打印履约结果与余额变化。
4. 链下互转：进行多次通道内互转（秒级确认），逐笔打印金额与耗时。
5. 完整性与关闭：校验资金守恒，关闭通道，打印主链余额返还情况。
```

说明：该脚本用于论文的“运行过程留痕”，可直接截图哈希锁、原像履约、余额变化与守恒校验日志。

伪代码：

```
function run():
  sim ← SimulationData()
  mgr ← BlockChainManager(PosConsensus(sim.validators), reward=30)
  mgr.balance_cache ← sim.initialize_balances()

  ch ← PaymentChannel("Alice", "Bob", 100, 100, mgr)
  open_ok ← ch.open_channel()
  print(lock(ch), balance(ch))

  preimage_a ← "ln_preimage_A"; h_a ← SHA256(preimage_a)
  preimage_b ← "ln_preimage_B"; h_b ← SHA256(preimage_b)
  ch.add_htlc("Alice","Bob",12, h_a, timelock=50)
  ch.add_htlc("Bob","Alice",8,  h_b, timelock=50)
  print(balance(ch))

  ok1 ← ch.fulfill_htlc(preimage_a, now=10)
  ok2 ← ch.fulfill_htlc(preimage_b, now=10)
  print(ok1, ok2, balance(ch))

  for (da, db) in [(-30,30), (20,-20), (-15,15)]:
    t0 ← now(); ch.update_state(da, db); t1 ← now()
    print(amount=|da|, elapsed=t1-t0, balance(ch))

  print(ch.validate_channel_integrity())
  ch.close_channel()
  print(balance_onchain(mgr, "Alice"), balance_onchain(mgr, "Bob"))
```
